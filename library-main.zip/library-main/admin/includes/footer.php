<footer class="main-footer">
    <div class="container">
      <div class="pull-center hidden-xs">
       <p class="pull-center"><b>Library Management System</b>
                  <span class="lead"> <i class="fa fa-university"></i> Saint Francis of Assisi College</span>
                </p>
      </div>
    <!-- /.container -->
</footer>