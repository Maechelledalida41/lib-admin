<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo (!empty($user['photo'])) ? '../images/'.$user['photo'] : '../images/profile.jpg'; ?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo $user['firstname'].' '.$user['lastname']; ?></p>
      </div>
    </div>

    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
        <li class="header" style="color: white">MAIN NAVIGATION</li>
        <li class="active">
          <a href="home.php">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

        <li>
          <a href="book.php">
            <i class="fa fa-book"></i> <span>Search Book</span>
          </a>
        </li>
         <li>
          <a href="ebook.php">
            <i class="fa fa-book"></i> <span>Search E-Book</span>
          </a>
        </li>
       
       <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Special Collection</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="thesis.php"><i class="fa fa-search"></i> Search Special Collection</a></li>
            <li><a href="add_thesis.php"><i class="fa fa-plus"></i> Add Special Collection</a></li>
            <li><a href="borrow_collection.php"><i class="fa fa-shopping-cart"></i> Special Collection Check-out </a></li>
            <li><a href="add_category.php"><i class="fa fa-list"></i> Categories</a></li>
            <li><a href="course.php"><i class="fa fa-list"></i> Courses</a></li>
          </ul>
        </li>
        <li class="header" style="color: white">USER MAINTENANCE</li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Users</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="user.php"><i class="fa fa-user"></i>Search User</a></li>
            <li><a href="add_user.php"><i class="fa fa-user-plus"></i> Add User</a></li>
          </ul>
        </li>

        <li class="header" style="color: white">BOOK MAINTENANCE</li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Books & E-Books</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="book.php"><i class="fa fa-plus"></i> Add Book</a></li>
            <!--<li><a href="add_author.php"><i class="fa fa-plus"></i> Add Author</a></li>-->
            <li><a href="ebook.php"><i class="fa fa-plus"></i> Add E-Book</a></li>
            <li><a href="moa.php"><i class="fa fa-plus"></i> Mode Of Acquisition</a></li>
            <!--<li><a href="add_subject.php"><i class="fa fa-plus"></i> Add Subject</a></li>-->
            <li><a href="publisher.php"><i class="fa fa-plus"></i> Publisher</a></li>
            <li><a href="pop.php"><i class="fa fa-plus"></i> Place of Publication</a></li>
          </ul>
        </li>
        <li class="header" style="color: white">LIBRARY SERVICES</li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Borrowing Services</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="borrow.php"><i class="fa fa-shopping-cart"></i>Reader Check-out</a></li>
            <li><a href="settings.php"><i class="fa fa-gear"></i>Settings</a></li>
          </ul>
        </li>
        <li class="header" style="color: white">SUMMARY REPORTS</li>
        <li>
          <a href="borrowed_book.php"><i class="fa fa-book"></i> <span>Borrowed Books</span></a>
        </li>
        <li>
          <a href="returned_book.php"><i class="fa fa-book"></i> <span>Returned Books</span></a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Utilization Records</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="utilization_record.php"><i class="fa fa-check"></i>Active Records</a></li>
            <li><a href="inactive_records.php"><i class="fa fa-times"></i>Inactive Records</a></li>
            <li><a href="inventory.php"><i class="fa fa-briefcase"></i>Inventory</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Archives</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="archives.php"><i class="fa fa-book"></i> <span>Inactive Books</span></a></li>
          <li><a href="arc_thesis.php"><i class="fa fa-book"></i> <span>Inactive Collection</span></a></li>
          </ul>
        </li>
        <li class="header" style="color: white">DATABASE MAINTENANCE</li>
        <li>
          <a href="backup.php"><i class="fa fa-database"></i> <span>Backup Database</span></a>
        </li>
        <li>
          <a href="restore.php"><i class="fa fa-database"></i> <span>Restore Database</span></a>
        </li>
      </ul>


  </section>
  <!-- /.sidebar -->
</aside>