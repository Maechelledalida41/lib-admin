<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$placeofpublication = $_POST['placeofpublication'];
		
		$sql = "INSERT INTO pop (placeofpublication) VALUES ('$placeofpublication')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Place of Publication added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: pop.php');

?>