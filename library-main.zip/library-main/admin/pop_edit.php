<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$placeofpublication = $_POST['placeofpublication'];

		$sql = "UPDATE pop SET placeofpublication = '$placeofpublication' WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Place of Publication updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
	}

	header('location:pop.php');

?>