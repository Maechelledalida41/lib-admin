<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$publishers = $_POST['publishers'];
		
		$sql = "INSERT INTO publishers (publishers) VALUES ('$publishers')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Publishers added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: publisher.php');

?>