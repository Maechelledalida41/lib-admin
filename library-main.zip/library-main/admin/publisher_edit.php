<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$publishers = $_POST['publishers'];

		$sql = "UPDATE publishers SET publishers = '$publishers' WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Publishers updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
	}

	header('location:publisher.php');

?>