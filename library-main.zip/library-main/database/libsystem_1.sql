/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : libsystem

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-09-21 07:57:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'sfacmain', '$2y$10$MiZ4m32jWz1WDRyYTxV28Oh24ouKwKtH2CFjtZrw95TuY2Jb4Azeq', 'SFAC', 'Las Piñas', '132932.jpg', '2022-05-31');

-- ----------------------------
-- Table structure for `books`
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `author` varchar(150) NOT NULL,
  `publisher` varchar(150) NOT NULL,
  `publish_date` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of books
-- ----------------------------
INSERT INTO `books` VALUES ('4', '0021', '5', 'Effective C++', 'Scott Meyers', 'Hoobstank Publishers', '2018-06-03', '1');
INSERT INTO `books` VALUES ('5', '01', '1', 'Software Engineering', 'ABCDEFF', 'Jacobs Publisher', '2018-05-07', '1');
INSERT INTO `books` VALUES ('6', '002', '5', 'Python Cookbook', 'ABCDEFF', 'Jacobs Publisher', '2018-06-01', '0');
INSERT INTO `books` VALUES ('7', '005', '1', 'Machinery Handbook', 'ABCDEFF', 'Jacobs Publisher', '2018-04-03', '1');
INSERT INTO `books` VALUES ('8', '555', '3', 'A Brief History of Time', 'Stephen Hawkings', 'Jacobs Publisher', '2018-06-09', '1');
INSERT INTO `books` VALUES ('9', '123', '5', 'Java 2', 'Herbert ', 'Demo Publisher', '2018-05-15', '0');

-- ----------------------------
-- Table structure for `borrow`
-- ----------------------------
DROP TABLE IF EXISTS `borrow`;
CREATE TABLE `borrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_borrow` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of borrow
-- ----------------------------
INSERT INTO `borrow` VALUES ('17', '3', '1', '2018-05-04', '0');
INSERT INTO `borrow` VALUES ('18', '3', '2', '2018-05-04', '1');
INSERT INTO `borrow` VALUES ('19', '5', '3', '2018-06-26', '0');
INSERT INTO `borrow` VALUES ('23', '6', '7', '2018-06-26', '0');
INSERT INTO `borrow` VALUES ('24', '6', '4', '2018-06-26', '0');

-- ----------------------------
-- Table structure for `category`
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', 'Engineering');
INSERT INTO `category` VALUES ('2', 'Mathematics');
INSERT INTO `category` VALUES ('3', 'Science and Technology');
INSERT INTO `category` VALUES ('4', 'History');
INSERT INTO `category` VALUES ('5', 'IT Programming');

-- ----------------------------
-- Table structure for `course`
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `code` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('1', 'Bachelor of Science in Information Systems', 'BSIS');
INSERT INTO `course` VALUES ('3', 'Bachelors of Information Technology', 'BIT');
INSERT INTO `course` VALUES ('4', '', '');

-- ----------------------------
-- Table structure for `ebooks`
-- ----------------------------
DROP TABLE IF EXISTS `ebooks`;
CREATE TABLE `ebooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) CHARACTER SET latin1 NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` text CHARACTER SET latin1 NOT NULL,
  `author` varchar(150) NOT NULL,
  `publisher` varchar(150) CHARACTER SET latin1 NOT NULL,
  `publisher_date` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of ebooks
-- ----------------------------

-- ----------------------------
-- Table structure for `moa`
-- ----------------------------
DROP TABLE IF EXISTS `moa`;
CREATE TABLE `moa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of moa
-- ----------------------------
INSERT INTO `moa` VALUES ('2', 'mae');

-- ----------------------------
-- Table structure for `pop`
-- ----------------------------
DROP TABLE IF EXISTS `pop`;
CREATE TABLE `pop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `placeofpublication` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of pop
-- ----------------------------
INSERT INTO `pop` VALUES ('4', 'maechelle');

-- ----------------------------
-- Table structure for `publishers`
-- ----------------------------
DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publishers` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of publishers
-- ----------------------------
INSERT INTO `publishers` VALUES ('18', 'mae');

-- ----------------------------
-- Table structure for `returns`
-- ----------------------------
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_return` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of returns
-- ----------------------------
INSERT INTO `returns` VALUES ('3', '3', '2', '2018-05-04');
INSERT INTO `returns` VALUES ('4', '3', '2', '2018-05-04');
INSERT INTO `returns` VALUES ('5', '6', '4', '2018-06-26');

-- ----------------------------
-- Table structure for `students`
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(15) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `course_id` int(11) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO `students` VALUES ('3', 'IMU702639514', 'Neovic', 'Devierte', 'facebook-profile-image.jpeg', '1', '2018-05-04');
INSERT INTO `students` VALUES ('4', 'TBD917438625', 'Gemalyn', 'Cepe', '', '2', '2018-05-04');
INSERT INTO `students` VALUES ('5', 'GSU960812475', 'Christine', 'Gray', '', '1', '2018-06-26');
INSERT INTO `students` VALUES ('6', 'NOY017542369', 'Tonny', 'Jr', '', '1', '2018-06-26');
