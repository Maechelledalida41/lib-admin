<footer class="main-footer">
    <div class="container">
      <div class="pull-center hidden-xs">
       <p class="pull-right">Library Management System
                  <span class="lead"> <i class="fa fa-university"></i> Saint Francis of Assisi College</span>
                </p>
      </div>
    <!-- /.container -->
</footer>